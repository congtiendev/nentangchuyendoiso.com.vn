@extends('layouts.main')

@section('page-title')
    {{__('Hỗ trợ kỹ thuật Pdf')}}
@endsection

@section('page-action')
@endsection

@section('content')
    <div class="row">
        <div class="menu d-flex justify-content-center">
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="loadPdf('admin.pdf')">Tài khoản quản trị viên</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="loadPdf('accounting.pdf')">Tài khoản nhân viên kế toán</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="loadPdf('client.pdf')">Tài khoản nhân viên quản trị khách hàng</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" onclick="loadPdf('crm_hrm.pdf')">Tài khoản nhân viên hành chính nhân sự</a>
                </li>
            </ul>
        </div>
        <div class="pdf-container">
            <div  id="pdf_container"></div>
        </div>
    </div>
@endsection

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.7.107/pdf.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.7.107/pdf_viewer.min.css" rel="stylesheet" type="text/css" />

    <script type="text/javascript">
        var pdfjsLib = window['pdfjs-dist/build/pdf'];
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.7.107/pdf.worker.min.js';
        var pdfDoc = null;
        var scale = 1; //Set Scale for zooming PDF.
        var resolution = 1; //Set Resolution to Adjust PDF clarity.
    
        function loadPdf(pdfName) {
            var url = "{{ asset('assets/pdf/') }}" + "/" + pdfName;
            LoadPdfFromUrl(url);
        }
    
        function LoadPdfFromUrl(url) {
            //Read PDF from URL.
            pdfjsLib.getDocument(url).promise.then(function (pdfDoc_) {
                pdfDoc = pdfDoc_;
    
                //Reference the Container DIV.
                var pdf_container = document.getElementById("pdf_container");
                pdf_container.style.display = "block";
                pdf_container.innerHTML = ""; // Clear any previous content.
    
                //Loop and render all pages.
                for (var i = 1; i <= pdfDoc.numPages; i++) {
                    RenderPage(pdf_container, i);
                }
            });
        }
    
        function RenderPage(pdf_container, num) {
    pdfDoc.getPage(num).then(function (page) {
        // Create Canvas element and append to the Container DIV.
        var canvas = document.createElement('canvas');
        canvas.id = 'pdf-' + num;
        pdf_container.appendChild(canvas);

        // Set the Canvas dimensions using ViewPort and Scale.
        var viewport = page.getViewport({ scale: scale });
        var resolution = 2; // Increase the resolution for better quality.
        canvas.height = resolution * viewport.height;
        canvas.width = resolution * viewport.width;

        // Render the PDF page.
        var renderContext = {
            canvasContext: canvas.getContext('2d'),
            viewport: viewport
        };

        page.render(renderContext);
    });
}
    </script>

    <style>

    </style>